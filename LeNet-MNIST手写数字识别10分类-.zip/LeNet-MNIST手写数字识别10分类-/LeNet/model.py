# 导入必要的库
import torch
from torch import nn
from torchsummary import summary

# 定义LeNet类，继承自nn.Module
class LeNet(nn.Module):

    """LeNet模型定义。"""

    def __init__(self):
        """
        初始化LeNet模型的层。
        包括卷积层、激活函数、池化层和全连接层。
        """
        super(LeNet, self).__init__()
        # 定义第一个卷积层，输入通道为1，输出通道为6，卷积核大小为5x5，padding为2
        self.c1 = nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, padding=2)
        # 定义Sigmoid激活函数
        self.sig = nn.Sigmoid()
        # 定义第一个平均池化层，池化窗口大小为2x2
        self.s2 = nn.AvgPool2d(kernel_size=2, stride=2)
        # 定义第二个卷积层，输入通道为6，输出通道为16，卷积核大小为5x5
        self.c3 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5)
        # 定义第二个平均池化层，池化窗口大小为2x2
        self.s4 = nn.AvgPool2d(kernel_size=2, stride=2)

        # 定义展平层，将二维特征图转换为一维向量
        self.flatten = nn.Flatten()
        # 定义第一个全连接层，输入大小为5*5*16，输出大小为120
        self.f5 = nn.Linear(5*5*16, 120)
        # 定义第二个全连接层，输入大小为120，输出大小为84
        self.f6 = nn.Linear(120, 84)
        # 定义第三个全连接层，输入大小为84，输出大小为10（分类数）
        self.f7 = nn.Linear(84, 10)

    def forward(self, x):
        """
        定义前向传播过程。
        """
        x = self.sig(self.c1(x))
        x = self.s2(x)
        x = self.sig(self.c3(x))
        x = self.s4(x)
        x = self.flatten(x)
        x = self.f5(x)
        x = self.f6(x)
        x = self.f7(x)
        return x

# 主程序入口
if __name__ == "__main__":
    # 检查是否有可用的GPU设备，如果有则使用GPU，否则使用CPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 实例化LeNet模型并转移到指定设备
    model = LeNet().to(device)
    # 打印模型摘要信息，输入数据形状为(1, 28, 28)
    print(summary(model, (1, 28, 28)))

    print("20210412430718-梁津永")