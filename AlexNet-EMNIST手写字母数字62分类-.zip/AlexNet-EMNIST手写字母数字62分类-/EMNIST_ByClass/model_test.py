import torch
import torch.utils.data as Data
from torchvision import transforms
from torchvision.datasets import  EMNIST
from model import AlexNet


def test_data_process():

    test_data = EMNIST(root="./data",
                             split="byclass",
                             train=False,
                             transform=transforms.Compose([transforms.Resize(size=28), transforms.ToTensor(),]),
                             download=True)

    # 创建测试集 DataLoader
    test_dataloader = Data.DataLoader(dataset=test_data,
                                      batch_size=1,
                                      shuffle=True,
                                      num_workers=0)

    return test_dataloader


def test_model_process(model, test_dataloader):

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = model.to(device)



    test_corrects = 0.0
    test_num = 0

    # 关闭梯度计算，减少内存消耗
    with torch.no_grad():
        for test_data_x, test_data_y in test_dataloader:
            test_data_x = test_data_x.to(device)
            test_data_y = test_data_y.to(device)

            # 设置模型为评估模式
            model.eval()

            # 前向传播
            output = model(test_data_x)
            pre_lab = torch.argmax(output, dim=1)
            test_corrects += torch.sum(pre_lab == test_data_y.data)
            test_num += test_data_x.size(0)

    # 计算测试准确率
    test_acc = test_corrects.double().item() / test_num
    print("测试的准确率为:", test_acc)

def print_predictions_and_labels(model, test_dataloader, classes):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    model.eval()

    # 关闭梯度计算，减少内存消耗
    with torch.no_grad():
        for b_x, b_y in test_dataloader:
            b_x = b_x.to(device)
            b_y = b_y.to(device)

            output = model(b_x)
            pre_lab = torch.argmax(output, dim=1)
            result = pre_lab.item()
            label = b_y.item()

            # 打印预测值和真实值
            print("预测值：", classes[result], "------", "真实值:", classes[label])


if __name__ == '__main__':
    # 实例化 AlexNet 模型
    model = AlexNet()

    # 加载最佳模型权重
    model.load_state_dict(torch.load('best_model.pth',weights_only=True))

    # 准备测试集数据
    test_dataloader = test_data_process()

    # 定义 EMNIST 类别名称
    classes = [
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
        'W', 'X', 'Y', 'Z',
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z'
    ]

    # 测试模型并打印准确率
    test_model_process(model, test_dataloader)

    # 打印每个样本的预测值和真实值
    print_predictions_and_labels(model, test_dataloader, classes)



