# 导入必要的库
import torch
from modelscope.models.audio.sv.TDNN import BatchNorm1d
from torch import nn
from torch.cuda import device as cuda_device
from torchsummary import summary


class AlexNet(nn.Module):

    def __init__(self):

        super(AlexNet, self).__init__()
        # 定义第一个卷积层，输入通道为1，输出通道为16，卷积核大小为3*3，步长为2
        self.c1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, stride=2, padding=2)
        # 定义ReLu激活函数
        self.relu = nn.ReLU()
        # 定义第一个最大池化层，池化窗口大小为2x2, 步长为2
        self.s1 = nn.MaxPool2d(kernel_size=2, stride=2)
        # 定义第二个卷积层，输入通道为16，输出通道为32，卷积核大小为3x3，填充为2
        self.c2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=2)
        # 定义第二个最大池化层，池化窗口大小为2x2, 步长为2
        self.s2 = nn.MaxPool2d(kernel_size=2, stride=2)

        # 定义第三到五的卷积层
        # 定义第三个卷积层，输入通道为32，输出通道为64，卷积核大小为3x3，填充为1
        self.c3 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, padding=1)
        # 定义第四个卷积层，输入通道为64，输出通道为128，卷积核大小为3x3，填充为1
        self.c4 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, padding=1)
        # 定义第五个卷积层，输入通道为384，输出通道为128，卷积核大小为256，填充为1
        self.c5 = nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, padding=1)
        # 定义第三个最大池化层，池化窗口大小为2x2, 步长为2
        self.s3 = nn.MaxPool2d(kernel_size=2, stride=2)

        # 定义展平层，将二维特征图转换为一维向量
        self.flatten = nn.Flatten()

        # 定义第一个全连接层
        # 输入图像大小为28x28，则经过c1, s1, c2, s2, c3, c4, c5, s3后的特征图大小为2*2*256
        self.f1 = nn.Linear(1024, 512)
        # 定义第二个全连接层，输入大小为512，输出大小为256
        self.f2 = nn.Linear(512, 256)
        # 定义第三个全连接层，输入大小为256，输出大小为62（分类数）
        self.f3 = nn.Linear(256, 62)



    #定义前向传播
    def forward(self, x):
        x = self.relu(self.c1(x))
        x = self.s1(x)
        x = self.relu(self.c2(x))
        x = self.s2(x)
        x = self.relu(self.c3(x))
        x = self.relu(self.c4(x))
        x = self.relu(self.c5(x))
        x = self.s3(x)
        x = self.flatten(x)
        x = self.f1(x)
        x = self.relu(x)
        x = self.f2(x)
        x = self.relu(x)
        x = self.f3(x)
        return x

# 主程序入口
if __name__ == "__main__":
    # 检查是否有可用的GPU设备，如果有则使用GPU，否则使用CPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 实例化LeNet模型并转移到指定设备
    model = AlexNet().to(device)
    # 打印模型摘要信息，输入数据形状为(1, 28, 28)
    print(summary(model, (1, 28, 28)))
