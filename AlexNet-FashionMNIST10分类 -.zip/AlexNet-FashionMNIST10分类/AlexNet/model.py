# 导入必要的库
import torch
from torch import nn
from torch.cuda import device as cuda_device
from torchsummary import summary

class AlexNet(nn.Module):

    def __init__(self):

        super(AlexNet, self).__init__()
        # 定义第一个卷积层，输入通道为1，输出通道为6，卷积核大小为5x5，padding为2
        self.c1 = nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, padding=2)
        # 定义ReLu激活函数
        self.relu = nn.ReLU()

        # 定义第一个最大池化层，池化窗口大小为2x2
        self.s1 = nn.MaxPool2d(kernel_size=2, stride=2)
        # 定义第二个卷积层，输入通道为6，输出通道为16，卷积核大小为5x5
        self.c2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5)
        # 定义第二个最大池化层，池化窗口大小为2x2
        self.s2 = nn.MaxPool2d(kernel_size=2, stride=2)
        # 定义第三到五的卷积
        self.c3 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1)
        self.c4 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, padding=1)
        self.c5 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, padding=1)
        self.s3 = nn.MaxPool2d(kernel_size=2, stride=2)

        # 定义展平层，将二维特征图转换为一维向量
        self.flatten = nn.Flatten()
        # 定义第一个全连接层，输入大小为2*2*128，输出大小为512
        self.f1 = nn.Linear(2*2*128, 512)
        # 定义第二个全连接层，输入大小为512，输出大小为128
        self.f2 = nn.Linear(512, 128)
        # 定义第三个全连接层，输入大小为128，输出大小为10（分类数）
        self.f3 = nn.Linear(128, 10)
        # 定义Dropout层，防止过拟合，丢弃概率为0.3
        self.dropout = nn.Dropout(p=0.3)

    #定义前向传播
    def forward(self, x):

        x = self.relu(self.c1(x))
        x = self.s1(x)
        x = self.relu(self.c2(x))
        x = self.s2(x)
        x = self.relu(self.c3(x))
        x = self.relu(self.c4(x))
        x = self.relu(self.c5(x))
        x = self.s3(x)
        x = self.flatten(x)
        x = self.relu(self.f1(x))
        x = self.dropout(x)
        x = self.relu(self.f2(x))
        x = self.dropout(x)
        x = self.relu(self.f3(x))
        return x

# 主程序入口
if __name__ == "__main__":
    # 检查是否有可用的GPU设备，如果有则使用GPU，否则使用CPU
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 实例化LeNet模型并转移到指定设备
    model = AlexNet().to(device)
    # 打印模型摘要信息，输入数据形状为(1, 28, 28)
    print(summary(model, (1, 28, 28)))
