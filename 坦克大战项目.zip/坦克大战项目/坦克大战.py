import time, pygame, random
from tkinter import *
from tkinter import messagebox
from pygame.sprite import Sprite

Game_width = 700
Game_height = 500
BG_color = pygame.Color(0, 0, 0)
Text_color = pygame.Color(255, 0, 0)


class Application(Frame):

    def __init__(self, master=None):
        super().__init__(master)  # super()代表的是父类的定义,而不是父类对象
        self.master = master
        self.pack()
        self.creatWidget()

    def creatWidget(self):
        # Label 03
        global photo
        # photo = PhotoImage(file="../坦克大战项目/img/图片1.png")
        photo = PhotoImage(file="../坦克大战项目/img/img.png")
        self.lab03 = Label(self, image=photo)
        self.lab03.pack()

        # 创建两个Frame，分别用于用户名和密码
        self.username_frame = Frame(self)
        self.password_frame = Frame(self)

        # 将两个Frame垂直排列
        self.username_frame.pack(pady=5)
        self.password_frame.pack(pady=5)

        # 用户名标签和输入框，水平布局在username_frame中
        self.lab01 = Label(self.username_frame, text="用户名：")
        self.lab01.pack(side=LEFT)

        v1 = StringVar()
        self.entry01 = Entry(self.username_frame, textvariable=v1)
        self.entry01.pack(side=LEFT, padx=5)  # 添加一些水平空间与标签分开

        # 密码标签和输入框，水平布局在password_frame中
        self.lab02 = Label(self.password_frame, text="密码：  ")
        self.lab02.pack(side=LEFT)

        v2 = StringVar()
        self.entry02 = Entry(self.password_frame, textvariable=v2, show="*")
        self.entry02.pack(side=LEFT, padx=5)  # 添加一些水平空间与标签分开


        # Button 01
        self.but01 = Button(self, width=10, height=2, text="游戏开始", command=self.login)
        self.but01.pack()

    def login(self):
        username = self.entry01.get()
        pwd = self.entry02.get()

        print("去数据库比对用户名和密码！")
        print("用户名：" + username)
        print("密码：  " + pwd)

        if username == "a" and pwd == "1":
            messagebox.showinfo("欢迎登录！", "登录成功开始上号")
            self.master.destroy()
            self.open_Maingame()

        else:
            messagebox.showinfo("登录失败")

    def open_Maingame(self):
        Maingame().startgame()


# 定义一个基类
class BaseItem(Sprite):
    def __init__(self, color, width, height):
        pygame.sprite.Sprite.__init__(self)


class Maingame():
    window = None
    my_tank = None
    enemy_tank = None
    # myTankList = []
    # 存储敌方坦克的列表
    enemyTankList = []
    # 定义敌方坦克的数量
    enemyTankCount = 5
    # 存储我方子弹的列表
    myBulletList = []
    # 存储敌方子弹的列表
    enemyBulletList = []
    # 存储爆炸效果的列表
    explodeList = []
    # 存储墙壁的列表
    wallList = []

    def __init__(self):
        pass

    # 开始游戏
    def startgame(self):
        # 加载主窗口
        # 初始化主窗口
        pygame.display.init()
        # 设置窗口的大小及显示
        Maingame.window = pygame.display.set_mode([Game_width, Game_height])
        # 初始化我方坦克
        self.createMyTank()
        # 初始化敌方坦克，并将敌方坦克添加到列表中
        self.createEnemyTank()
        # 初始化墙壁
        self.createWall()

        # 设置窗口的标题
        pygame.display.set_caption("坦克大战0.0.1")
        while True:
            time.sleep(0.015)
            # 给窗口设置填充色
            Maingame.window.fill(BG_color)
            # 获取事件
            self.getEvent()
            Maingame.window.blit(self.getTextSuface("敌方剩余坦克数量:%d" % len(Maingame.enemyTankList)), (10, 10))
            # 调用坦克显示的方法
            # 判断我方坦克是否存活
            if Maingame.my_tank and Maingame.my_tank.live:
                Maingame.my_tank.displayTank()

            else:
                # 删除我方坦克
                del Maingame.my_tank
                Maingame.my_tank = None
            # 循环遍历敌方坦克列表，展示敌方坦克
            self.blitEnemyTank()
            # 循环遍历显示我方坦克的子弹
            self.blitMyBullet()
            # 循环遍历敌方子弹列表，展示敌方子弹
            self.blitEnemyBullet()
            # 循环遍历爆炸列表，展示爆炸效果
            self.blitExplode()
            # 循环遍历墙壁列表，展示墙壁
            self.biltWall()
            # 调用移动方法
            # 如果坦克的开关是开启，才可以移动
            if Maingame.my_tank and Maingame.my_tank.live:
                if not Maingame.my_tank.stop:
                    Maingame.my_tank.move()
                    # 检测我方坦克是否与墙壁发生碰撞
                    Maingame.my_tank.hitWall()
                    # print("坦克已与墙壁碰撞！")
                    # 检测我方坦克是否与地方坦克发生碰撞
                    Maingame.my_tank.myTank_hit_enemyTank()

            pygame.display.update()

    # 循环遍历墙壁列表，展示墙壁
    def biltWall(self):
        for wall in Maingame.wallList:
            # 判断墙壁是否存活
            if wall.live:
                # 调用墙壁的展示方法
                wall.displaywall()
            else:
                Maingame.wallList.remove(wall)

    # 初始化墙壁
    def createWall(self):
        # 初始化墙壁
        for i in range(1, 4):
            wall = Wall(i * 160, 160)
            # 将墙壁添加到列表中
            Maingame.wallList.append(wall)
        for j in range(1, 4):
            wall1 = Wall(j * 160, 320)
            # 将墙壁添加到列表中
            Maingame.wallList.append(wall1)

    # 初始化我方坦克
    def createMyTank(self):
        Maingame.my_tank = MyTank(250, 300)
        # 创建Music对象
        # music = Music("")
        # music.play()

    # 初始化敌方坦克，并将敌方坦克添加到列表中
    def createEnemyTank(self):
        top = 100
        # 循环生成敌方坦克
        for i in range(Maingame.enemyTankCount):
            left = random.randint(0, 600)
            speed = random.randint(1, 4)
            enemy = EmenyTank(left, top, speed)
            Maingame.enemyTankList.append(enemy)

    def blitExplode(self):
        for explode in Maingame.explodeList:
            # 判断是否活着
            if explode.live:
                # 展示
                explode.displayExplode()
                # print("坦克爆炸了")
            else:
                # 在爆炸列表中删除
                Maingame.explodeList.remove(explode)
                # print("坦克没爆炸")

    # 循环遍历敌方坦克列表，展示敌方坦克
    def blitEnemyTank(self):
        for enemyTank in Maingame.enemyTankList:
            # 判断当前敌方坦克是否活着
            if enemyTank.live:
                enemyTank.displayTank()
                enemyTank.randMove()
                # 检测敌方坦克是否撞墙
                enemyTank.hitWall()
                # 检测地方坦克是否与我方坦克发生碰撞
                if Maingame.my_tank and Maingame.my_tank.live:
                    enemyTank.enemyTank_hit_myTank()
                # 敌方坦克发射子弹
                enemyBullet = enemyTank.shot()
                # 敌方子弹是否为None不为None则添加到子弹列表中
                if enemyBullet:
                    Maingame.enemyBulletList.append(enemyBullet)
            else:
                # 不活着，从地方坦克列表中移除
                Maingame.enemyTankList.remove(enemyTank)

    # 循环遍历我方子弹的存储列表
    def blitMyBullet(self):
        for myBullet in Maingame.myBulletList:
            # 判断当前的子弹是否处于活着的状态，如果是则进行显示及移动
            if myBullet.live:
                myBullet.displayBullet()
                # 调用坦克的移动方法
                myBullet.move()
                myBullet.myBullet_hit_enemyTank()
                myBullet.hitWall()
            else:
                Maingame.myBulletList.remove(myBullet)

    # 循环遍历敌方子弹列表，展示敌方子弹
    def blitEnemyBullet(self):
        for enemyBullet in Maingame.enemyBulletList:
            if enemyBullet.live:
                enemyBullet.displayBullet()
                # 调用坦克的移动方法
                enemyBullet.move()
                enemyBullet.enemyBullet_hit_myTank()
                enemyBullet.hitWall()
            else:
                Maingame.enemyBulletList.remove(enemyBullet)

    # 结束游戏
    def endgame(self):
        print("游戏关闭")
        exit()

    # 左上角文字的绘制
    def getTextSuface(self, text):
        # 初始化字体模块
        pygame.font.init()
        # 获取字体Font的对象
        font = pygame.font.SysFont("kaiti", 18)
        # 绘制文字信息
        textSurface = font.render(text, True, Text_color)
        return textSurface

    # 获取事件
    def getEvent(self):
        # 获取所有事件
        eventList = pygame.event.get()
        # 遍历事件
        for event in eventList:
            # 判断按下的键是关闭还是键盘按下
            # 如果按的是退出，关闭窗口
            if event.type == pygame.QUIT:
                self.endgame()
            # 如果是键盘的按下
            if event.type == pygame.KEYDOWN:
                # 当坦克不存在或者死亡
                if not Maingame.my_tank:
                    # 判断按下的是esc键，让坦克重生
                    if event.key == pygame.K_ESCAPE:
                        # 让坦克重生及调用创建坦克的方法
                        self.createMyTank()
                if Maingame.my_tank and Maingame.my_tank.live:
                    # 如果是按下 上,下,左,右键 则坦克向上，下，左，右移动
                    if event.key == pygame.K_LEFT:
                        # 切换方向
                        Maingame.my_tank.direction = "L"
                        Maingame.my_tank.stop = False
                        # Maingame.my_tank.move()
                        print("按下左键，坦克向左移动")

                    elif event.key == pygame.K_RIGHT:
                        Maingame.my_tank.direction = "R"
                        Maingame.my_tank.stop = False
                        print("按下右键，坦克向右移动")

                    elif event.key == pygame.K_UP:
                        Maingame.my_tank.direction = "U"
                        Maingame.my_tank.stop = False
                        print("按下上键，坦克向上移动")

                    elif event.key == pygame.K_DOWN:
                        Maingame.my_tank.direction = "D"
                        Maingame.my_tank.stop = False
                        print("按下下键，坦克向下移动")
                    elif event.key == pygame.K_SPACE:
                        print("子弹发射")
                        Maingame.my_tank.shot()
                        if len(Maingame.myBulletList) <= 1:
                            # 创建我方坦克发射的子弹
                            mybullet = Bullet(Maingame.my_tank)
                            Maingame.myBulletList.append(mybullet)

                        if Maingame.enemy_tank is not None:
                            Maingame.enemy_tank.shot()
                            if len(Maingame.enemyBulletList) < 1:
                                enemybullet = Bullet(Maingame.enemy_tank)
                                Maingame.enemyBulletList.append(enemybullet)

            # 松开按键开关打开
            if event.type == pygame.KEYUP:
                if (event.key == pygame.K_UP or event.key == pygame.K_LEFT
                        or event.key == pygame.K_RIGHT or event.key == pygame.K_DOWN):
                    if Maingame.my_tank and Maingame.my_tank.live:
                        Maingame.my_tank.stop = True


class Tank(BaseItem):
    def __init__(self, top, left):
        # 保存加载的图片
        self.images = {
            'U': pygame.image.load("img/tanku.png"),
            'D': pygame.image.load("img/tankd.png"),
            'L': pygame.image.load("img/tankl.png"),
            'R': pygame.image.load("img/tankr.png"),
        }
        # 方向
        self.direction = "U"
        # 根据当前图片的方向获取图片 surface
        self.image = self.images[self.direction]
        # 根据图片获取区域
        self.rect = self.image.get_rect()
        # 设置区域的left和top
        self.rect.left = left
        self.rect.top = top
        # 速度 决定移动的快慢
        self.speed = 8
        # 坦克移动的开关
        self.stop = True
        # 是否活着
        self.live = True
        # 新增属性原来坐标
        self.oldLeft = self.rect.left
        self.oldTop = self.rect.top

    # 移动
    def move(self):
        # 移动后记录原始的坐标
        self.oldLeft = self.rect.left
        self.oldTop = self.rect.top
        # 判断坦克的方向进行移动
        if self.direction == 'L':
            if self.rect.left > 0:
                self.rect.left -= self.speed
        elif self.direction == 'U':

            if self.rect.top > 0:
                self.rect.top -= self.speed
        elif self.direction == 'D':
            if self.rect.top + self.rect.height < Game_height:
                self.rect.top += self.speed
        elif self.direction == 'R':
            if self.rect.left + self.rect.height < Game_width:
                self.rect.left += self.speed

    # 射击
    def shot(self):
        return Bullet(self)

    #
    def stay(self):
        self.rect.left = self.oldLeft
        self.rect.top = self.oldTop

    # 检测坦克是否与墙壁发生碰撞
    def hitWall(self):
        for wall in Maingame.wallList:
            if pygame.sprite.collide_rect(self, wall):
                # 将坐标设置为移动之前的坐标
                self.stay()

    # 展示坦克的方法
    def displayTank(self):
        # 获取展示的对象
        self.image = self.images[self.direction]
        # 调用blit方法展示
        Maingame.window.blit(self.image, self.rect)


# 我方坦克
class MyTank(Tank):
    def __init__(self, left, top):
        super(MyTank, self).__init__(left, top)

    # 检测我方坦克与敌方坦克发生碰撞
    def myTank_hit_enemyTank(self):
        # 循环遍历
        for enemyTank in Maingame.enemyTankList:
            if pygame.sprite.collide_rect(self, enemyTank):
                self.stay()


# 敌方坦克
class EmenyTank(Tank):
    def __init__(self, left, top, speed):
        # 加载图片集
        super(EmenyTank, self).__init__(left, top)
        etwidth = 60
        etheight = 60
        self.images = {
            'U': pygame.transform.scale(pygame.image.load('img/DTu.png'), (etwidth, etheight)),
            'D': pygame.transform.scale(pygame.image.load('img/DTd.png'), (etwidth, etheight)),
            'L': pygame.transform.scale(pygame.image.load('img/DTl.png'), (etwidth, etheight)),
            'R': pygame.transform.scale(pygame.image.load('img/DTr.png'), (etwidth, etheight)),
        }

        # 方向,随机生成敌方坦克的方向
        self.direction = self.randDirection()
        # 根据方向获取图片
        self.image = self.images[self.direction]
        # 区域
        self.rect = self.image.get_rect()
        # 对left和top进行赋值
        self.rect.left = left
        self.rect.top = top
        # 速度
        self.speed = speed
        # 移动开关键
        self.flag = True
        # 定义新增步数变量 step
        self.step = 60

    def enemyTank_hit_myTank(self):
        if pygame.sprite.collide_rect(self, Maingame.my_tank):
            self.stay()

    # 随机生成敌方坦克的方向
    def randDirection(self):
        num = random.randint(1, 4)
        if num == 1:
            return 'U'
        elif num == 2:
            return 'D'
        elif num == 3:
            return 'L'
        elif num == 4:
            return 'R'

    # 敌方坦克随机移动的方法
    def randMove(self):
        if self.step <= 0:
            # 修改方向
            self.direction = self.randDirection()
            self.step = 60
        else:
            self.move()
            # 让步数递减
            self.step -= 1

    def shot(self):
        # 设置敌方坦克的炮弹发射速度
        # 随机生成100以内的数
        num = random.randint(1, 100)
        if num <= 1:
            return Bullet(self)


class Bullet(BaseItem):
    def __init__(self, tank):
        # 加载图片
        imgrlwidth = 60
        imgrlheight = 20
        imgudwidth = 20
        imgudheight = 60

        self.imageu = pygame.image.load('img/paodanu.png')
        self.imaged = pygame.image.load('img/paodand.png')
        self.imagel = pygame.image.load('img/paodanl.png')
        self.imager = pygame.image.load('img/paodanr.png')

        self.imageU = pygame.transform.scale(self.imageu, (imgudwidth, imgudheight))
        self.imageD = pygame.transform.scale(self.imaged, (imgudwidth, imgudheight))
        self.imageL = pygame.transform.scale(self.imagel, (imgrlwidth, imgrlheight))
        self.imageR = pygame.transform.scale(self.imager, (imgrlwidth, imgrlheight))
        # 坦克的方向决定子弹的方向
        self.direction = tank.direction
        # 获取区域
        # 子弹的left和top与方向有关
        if self.direction == 'U':
            self.rect = self.imageU.get_rect()
            self.rect.left = tank.rect.left + tank.rect.width / 2 - self.rect.width / 2
            self.rect.top = tank.rect.top - self.rect.height
        elif self.direction == 'D':
            self.rect = self.imageD.get_rect()
            self.rect.left = tank.rect.left + tank.rect.width / 2 - self.rect.width / 2
            self.rect.top = tank.rect.top + self.rect.height
        elif self.direction == 'L':
            self.rect = self.imageL.get_rect()
            self.rect.left = tank.rect.left - tank.rect.width / 2 - self.rect.width / 2
            self.rect.top = tank.rect.top + tank.rect.height / 2 - self.rect.height / 2
        elif self.direction == 'R':
            self.rect = self.imageR.get_rect()
            self.rect.left = tank.rect.left + tank.rect.width
            self.rect.top = tank.rect.top + tank.rect.height / 2 - self.rect.height / 2
        # 子弹的速度
        self.speed = 12
        # 坦克移动的开关
        self.stop = True
        # 子弹的状态，是否可以碰到墙壁，如果碰到，修改此状态
        self.live = True
        # 我方坦克的状态

    # 移动
    def move(self):
        if self.direction == 'U':
            if self.rect.top > 0:
                self.rect.top -= self.speed
            else:
                # 修改子弹的状态
                self.live = False
        elif self.direction == 'R':
            if self.rect.left + self.rect.width < Game_width:
                self.rect.left += self.speed
            else:
                # 修改子弹的状态
                self.live = False
        elif self.direction == 'D':
            if self.rect.top + self.rect.height < Game_height:
                self.rect.top += self.speed
            else:
                # 修改子弹的状态
                self.live = False
        elif self.direction == 'L':
            if self.rect.left > 0:
                self.rect.left -= self.speed
            else:
                # 修改子弹的状态
                self.live = False

    # 子弹是否碰撞墙壁
    def hitWall(self):
        # 循环遍历列表
        for wall in Maingame.wallList:
            if pygame.sprite.collide_rect(self, wall):
                # 修改子弹的生存状态
                self.live = False
                # 墙壁的生命值减少
                wall.hp -= 1
                if wall.hp <= 0:
                    # 修改墙壁的状态
                    wall.live = False

    # 展示子弹的方法
    def displayBullet(self):
        # 将图片加载到窗口
        # 各个方向对应各个图片
        if self.direction == 'U':
            Maingame.window.blit(self.imageU, self.rect)
        elif self.direction == 'R':
            Maingame.window.blit(self.imageR, self.rect)
        elif self.direction == 'D':
            Maingame.window.blit(self.imageD, self.rect)
        elif self.direction == 'L':
            Maingame.window.blit(self.imageL, self.rect)

    # 我方子弹与敌方坦克的碰撞
    def myBullet_hit_enemyTank(self):
        # 循环遍历敌方坦克列表，判断是否发生碰撞
        for enemyTank in Maingame.enemyTankList:
            if pygame.sprite.collide_rect(enemyTank, self):
                # 修改敌方坦克和我方子弹的状态
                enemyTank.live = False
                self.live = False
                # 创建爆炸对象
                explode = Explode(enemyTank)
                # 将爆炸对象添加到爆炸列表中
                Maingame.explodeList.append(explode)

    # 敌方子弹与我方坦克发生碰撞
    def enemyBullet_hit_myTank(self):
        if Maingame.my_tank and Maingame.my_tank.live:
            if pygame.sprite.collide_rect(Maingame.my_tank, self):
                # 产生爆炸对象
                explode = Explode(Maingame.my_tank)
                # 将爆炸对象添加到爆炸列表中
                Maingame.explodeList.append(explode)
                # 修改敌方坦克与我方坦克的状态
                self.live = False
                Maingame.my_tank.live = False


class Wall():
    def __init__(self, left, top):
        # 加载墙壁图片
        wallwidth = 75
        wallheight = 75
        self.imageb = pygame.image.load('img/QiangBi.png')
        self.imageB = pygame.transform.scale(self.imageb, (wallwidth, wallheight))

        # 获取墙壁的区域
        self.rect = self.imageB.get_rect()
        # 设置位置 left top
        self.rect.left = left
        self.rect.top = top
        # 是否存活
        self.live = True
        # 设置生命值
        self.hp = 5

    # 展示墙壁的方法
    def displaywall(self):
        Maingame.window.blit(self.imageB, self.rect)


class Explode():
    def __init__(self, tank):
        # 爆炸的位置由当前子弹击中坦克的位置决定
        self.rect = tank.rect
        self.images = [
            pygame.image.load('img/boom.png')
        ]
        self.step = 0
        self.image = self.images[self.step]
        # 是否活着
        self.live = True

    # 展示爆炸效果的方法
    def displayExplode(self):
        if self.step <= len(self.images):
            # 根据索引获取爆炸对象
            self.image = self.images[self.step]


# class Music():
#     def __init__(self, filename):
#         self.filename = filename
#         # 初始化音乐混合器
#         pygame.mixer.init()
#         # 加载音乐
#         pygame.mixer.music.load(self.filename)
#
#     # 播放音乐
#     def play(self):
#         pygame.mixer.music.play()


if __name__ == "__main__":
    root = Tk()
    root.geometry("500x500+300+300")
    app = Application(master=root)
    root.title("坦克大战登录界面！")
    root.mainloop()
    # Maingame().startgame()
