import torch
from torch import nn
from torchsummary import summary

# 搭建VGG16网络
class VGG16(nn.Module):
    def __init__(self, num_classes=10):
        super(VGG16, self).__init__()
        self.features = nn.Sequential(
            # 卷积层1, 输出通道数为32
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            # 批归一化层
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            # 卷积层2, 输出通道数为64
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            # 最大池化层
            nn.MaxPool2d(kernel_size=2, stride=2),

            # 卷积层3 , 输出通道数为128
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            # 卷积层4, 输出通道数为256
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )

        # 全局平均池化层，将特征图尺寸调整为2x2
        self.avgpool = nn.AdaptiveAvgPool2d((2, 2))

        # 计算全连接层的输入尺寸
        self.feat_dim = 256 * 2 * 2  # 2x2 是经过自适应平均池化后的特征图尺寸
        self.classifier = nn.Sequential(
            nn.Linear(self.feat_dim, 256),  # 减少全连接层的节点数
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, 10)
        )

    # 前向传播函数
    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)  # 展平特征图
        x = self.classifier(x)
        return x


# 主程序入口
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 实例化VGG16模型并转移到指定设备
    model = VGG16(num_classes=10).to(device)
    # 打印模型摘要信息，输入数据形状为(1, 28, 28)，MNIST图像的尺寸
    print(summary(model, input_size=(1, 28, 28)))